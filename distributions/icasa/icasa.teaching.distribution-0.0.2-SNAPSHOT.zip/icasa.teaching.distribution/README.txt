This is an M2MAppBuilder distribution.
You can find more information including source code on the icasa.teaching.distribution website (https://github.com/AdeleResearchGroup/M2MAppBuilder).

This software is license under Apache V2 license.

To launch it, execute icasa.teaching.distribution.bat or iCasa file depending on your operating system.

----------- Building Guide --------------
To build it, execute mvn install.